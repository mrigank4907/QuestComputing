
function Validator() {
    var $form;

    function init() {
        $form = $('.form');
        $form.submit(validate);
    }

    function validate() {
        return required() && pps() && date() && mobile() ;
    }

    function pps() {
        var value = $form.find('#pps').val();
        if (!/^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(value)) {
            $form.find('#pps').addClass('error');
            return false;
        }
        return true;
    }

    function required() {
        var $required = $form.find('.required');
        var isValid = true;
        $.each($required, function (i, val) {
            $(val).removeClass('error');
            if ($(val).val() == "") {
                isValid = false;
                $(val).addClass('error');
            }
        });
        return isValid;
    }

    function date() {
        var $birthday = $form.find('.birthday');
        $($birthday).removeClass('error');
        var date = $birthday.val().split('/');
        var formattedDate = date[2]+'-'+date[1]+"-"+date[0];
        if (/Invalid|NaN/.test(new Date(formattedDate))) {
            $($birthday).addClass('error');
            return false;
        }
        var dob = new Date(formattedDate);
        var now = new Date();
        if (now < dob) {
            $($birthday).addClass('error');
            return false;
        }

        return true;
    }

    function mobile() {
        var value = $form.find('#mobile').val();
        $form.find('#mobile').removeClass('error');
        if (!/^((08)\d+)?$/.test(value)) {
            $form.find('#mobile').addClass('error');
            return false;
        }
        return true;
    }
    init();
}
var validator = new Validator();
