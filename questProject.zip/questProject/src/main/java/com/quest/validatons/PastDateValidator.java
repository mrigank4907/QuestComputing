package com.quest.validatons;

import java.util.Calendar;
import java.util.Date;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


public class PastDateValidator implements ConstraintValidator<PastDate, Date> {

    @Override
    public final void initialize(final PastDate annotation) {
    }

    @Override
    public final boolean isValid(final Date value, final ConstraintValidatorContext context) {
        if (value == null) {
            return false;
        }
        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();
        return value.before(today);

    }
}
