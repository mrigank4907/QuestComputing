package com.quest.services;

import com.quest.configuration.Person;

public interface PersonService {
    Iterable<Person> listAllPeople();

    Person getPersonById(Long id);

    Person savePerson(Person person);
}
