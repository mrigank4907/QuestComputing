package com.quest.configuration;

import com.quest.validatons.PastDate;
import javax.persistence.*;
import java.util.Date;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull(message = "PPS must be provided")
    @Column(name="pps", nullable=false, unique=true)
    private Long pps;
    
    @Version
    private Integer version;
    
    @NotBlank(message = "Name must be provided")
    @Size(max = 10, message = "Max 25 Characters.")
    private String name;
    
    //@NotBlank(message="Please informe a valid date of birth")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    @PastDate
    private Date birthday;
    
    @Pattern(regexp = "^0?8?.*", message="Mobile must begin with 08 prefix")
    private String mobile;
    
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdat;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatedat() {
        return createdat;
    }

    public void setCreatedat(Date createdat) {
        this.createdat = createdat;
    }


    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getPps() {
        return pps;
    }

    public void setPps(Long pps) {
        this.pps = pps;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    @Override
    public String toString() {
        return "Person{" + "id=" + id + ", pps=" + pps + ", version=" + version + ", name=" + name + ", birthday=" + birthday + ", mobile=" + mobile + ", createdat=" + createdat + '}';
    }
    
}
