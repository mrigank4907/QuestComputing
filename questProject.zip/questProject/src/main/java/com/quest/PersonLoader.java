package com.quest;

import java.time.LocalDate;
import java.time.Month;
import java.util.Calendar;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.quest.configuration.Person;
import com.quest.configuration.PersonRepository;

import java.util.Date;

@Component
public class PersonLoader implements ApplicationListener<ContextRefreshedEvent> {

    private PersonRepository personRepository;

    private Logger log = Logger.getLogger(PersonLoader.class);

    @Autowired
    public void setPersonRepository(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {

        Person mrigank = new Person();
        mrigank.setPps(123456L);
        mrigank.setName("mrigank");
        LocalDate localDate = LocalDate.of(1991, Month.AUGUST, 30);
        mrigank.setBirthday(java.sql.Date.valueOf(localDate));
        mrigank.setMobile("0899788987");

        log.info("Saved Mrigank - id: " + mrigank.getPps());

        Person steve = new Person();
        steve.setPps(1234567L);
        steve.setName("steve");
        steve.setBirthday(java.sql.Date.valueOf(localDate));
        steve.setMobile("087789876");

        log.info("Saved steve - id:" + steve.getPps());
    }
}
