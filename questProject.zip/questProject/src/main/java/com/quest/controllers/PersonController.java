package com.quest.controllers;

import com.quest.configuration.Person;
import com.quest.services.PersonService;
import javax.validation.Valid;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class PersonController {

    private PersonService personService;

    @Autowired
    public void setPersonService(PersonService personService) {
        this.personService = personService;
    }

    @RequestMapping(value = "/people", method = RequestMethod.GET)
    public String list(Model model) {
        model.addAttribute("people", personService.listAllPeople());
        return "people";
    }

    @RequestMapping("person/{id}")
    public String showPerson(@PathVariable Long id, Model model) {
        model.addAttribute("person", personService.getPersonById(id));
        return "personshow";
    }

    @RequestMapping("person/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        model.addAttribute("person", personService.getPersonById(id));
        return "personform";
    }

    @RequestMapping("person/new")
    public String newPerson(Model model) {
        model.addAttribute("person", new Person());
        return "personform";
    }

    @RequestMapping(value = "person", method = RequestMethod.POST)
    public String savePerson(Model model, @Valid Person person, BindingResult result) {
        if (result.hasErrors()) {
            return "personform";
        }
        try {
            personService.savePerson(person);
        } catch (Exception ex) {
            Throwable cause = ex.getCause();
            if (cause instanceof ConstraintViolationException) {
                person.setVersion(null);
                model.addAttribute("person", person);
                model.addAttribute("constraint", "Constraint violation");
                return "personform";
            }   
        }
        return "redirect:/person/" + person.getId();
    }

}
