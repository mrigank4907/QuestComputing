# Quest Application test

To run the project `mvn package && java -jar target/spring-boot-web-0.0.1-SNAPSHOT.jar`

## Requirements 
Develop a web application to capture and store demographic details.
required 3 pages (Home, add and list)

## Final application
I created 5 pages(Login, List, add, edit and show individual records)

Validation was done on front end and backend;

The validation on front was done using no plugins, just jQuery(oprtunity to show my skills with JS);

The Layout was done using Bootstrap framework;

I added a simple authentication system to access the pages, it was done with Spring Security.
No Authorization system added because the time.

There are some integration tests, testing some database operations;

## Tech Stack
* Spring Boot
* Spring MVC
* Spring Data
* Spring Security
* Hibernate
* Thymeleaf
* jQuery
* Bootstrap
* Junit



